import { NgModule, Component, Injectable} from '@angular/core';
import { APP_BASE_HREF, CommonModule } from '@angular/common';
import { Routes, Route, ExtraOptions, RouterModule, CanActivate, CanLoad, CanDeactivate, PreloadAllModules } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CounterComponent } from './counter/counter.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { ErrorpageComponent } from './errorpage/errorpage.component';
import { LoginComponent } from './login/login.component';

export const routes: Routes = [
    { path: '', component: HomeComponent, pathMatch: 'full' },
    { path: 'counter', component: CounterComponent },
    { path: 'fetch-data', component: FetchDataComponent },
    // { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard], canDeactivate: [AlertGuard]  },
     { path: 'login', component: LoginComponent },
    // { path: '**', component: ErrorpageComponent  },
    { path: 'helps', loadChildren: './modules/orders/orders.module#OrdersModule'},
    { path: '**', component: ErrorpageComponent}
];
const config: ExtraOptions = {
    useHash: true,
    // enableTracing: true ,
    preloadingStrategy: PreloadAllModules
  };

@NgModule({
    imports: [RouterModule.forRoot(routes, config)],
    exports: [RouterModule],
    providers: [
      // AlertGuard, AuthGuard,
        { provide: APP_BASE_HREF, useValue: '/' },
      ],
      declarations: []
})

export class AppRoutingModule { }

