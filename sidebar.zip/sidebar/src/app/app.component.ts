import { Component, OnInit } from '@angular/core';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { Router } from '@angular/router';
import { BreadcrumbService } from './shared/utils/breadcrumb.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  title = 'app';
  idleState = 'Not started.';
  breadcrumb: Array<any> = [];
  breadcrumbList: Array<any> = [];
  constructor(private idle: Idle, private keepalive: Keepalive, private _router: Router, private breadcrumService: BreadcrumbService) {
    this.subscribeTheIdle(idle);
  }
  ngOnInit() {
    this.listenRouting();
    this.breadcrumb = this.breadcrumService.getBreadcrumb();
  }

  /* updating the breadcrumb  */
  listenRouting() {
    let routerUrl: string, routerList: Array<any>, target: any;
    this._router.events.subscribe((router: any) => {
      routerUrl = router.urlAfterRedirects;
      if (routerUrl && typeof routerUrl === 'string') {
        target = this.breadcrumb;
        this.breadcrumbList.length = 0;
        routerList = routerUrl.slice(1).split('/');
        routerList.forEach((rowrouter, index) => {
          if (isNaN(rowrouter)) {
          if (target !== undefined && target.length !== 0) {
          target = target.find(page => page.path.slice(2) === rowrouter);
          if (target !== undefined && target.length !== 0) {
          this.breadcrumbList.push({
            name: target.name,
            path: (index === 0) ? target.path : `${this.breadcrumbList[index - 1].path}/${target.path.slice(2)}`
          });
          if (index + 1 !== routerList.length) {
            target = target.children;
          }
        }
      }
    }
        });
      }
    });
  }
  subscribeTheIdle(idle) {
    // sets an idle timeout of 5 seconds, for testing purposes.
    idle.setIdle(5);
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    idle.setTimeout(5);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    idle.onIdleEnd.subscribe(() => {
      this.idleState = 'No longer idle.';
    });
    idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out!';
      this.reset();
    });
    idle.onIdleStart.subscribe(() => {
      this.idleState = 'You\'ve gone idle!';
    }
    );
    this.reset();
  }

  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
  }
}
