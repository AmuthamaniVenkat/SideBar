import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderTableComponent } from './order-table/order-table.component';
import { OrdersService } from './orders.service';
import { SharedModule } from 'src/app/shared/shared.module';
import { Routes, RouterModule } from '@angular/router';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { TableComponent } from './table/table.component';
import { CarService } from './table/car.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

const routes: Routes = [

  {
    path: '',
    component: OrderTableComponent,
     children: [
      { path: 'helps/:accountId/:patientId', component: OrderTableComponent, data: { label: 'Helps', title: 'Helps' } },
    ]
  },
];

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(routes),
  ],
  declarations: [OrderTableComponent, ReactiveFormComponent, TableComponent],
  providers: [OrdersService, CarService],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA ],
  exports: [
    OrderTableComponent,
    RouterModule
  ]
})
export class OrdersModule { }
