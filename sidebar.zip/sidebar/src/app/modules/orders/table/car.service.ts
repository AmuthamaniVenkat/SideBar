import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CarService {

  constructor(private http: HttpClient) {}

    getCarsSmall(): Observable<any> {
    return this.http.get('assets/data/cars-small.json');
    }
}
