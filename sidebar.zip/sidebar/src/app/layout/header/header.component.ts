import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { MenubarModule } from 'primeng/menubar';
import { MegaMenuModule } from 'primeng/megamenu';
import { MenuModule, MenuItem } from 'primeng/primeng';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
})

export class HeaderComponent implements OnInit {
  @Output() toggleOpenedForEmit = new EventEmitter();
  @Input() breadcrumbs: string;
  user: object;
  userMenu: MenuItem[];
  constructor() {
    this.user = {
      isAuthenticated: true,
      userName: 'DATest',
      userDisplayname: 'DATest'
    };
    this.userMenu = [{
      label: 'DATest', icon: 'icon-login login_icon',
      items: [
        { label: 'Logout', icon: 'glyphicon glyphicon-log-out' },
        { label: 'Training', icon: 'icon-training' }
      ]
      }
    ];
  }
  ngOnInit() {
  }

  toggleOpened(): void {
    this.toggleOpenedForEmit.emit();
  }
}
// export class HeaderComponent implements OnInit {
//  items: MenuItem[];
//  loginmenu: MenuItem[];
//  logoutStatus = false;
//  pilots: any;
//  inPilot = false;
//    constructor(
//    private menuObservableService: MenuObservableService,
//    private appConfig: AppConfig,
//    private router: Router,
//    private route: ActivatedRoute,
//    private authService: AuthenticationService,
//  ) {
//  }
//  user = this.appConfig.user;
//  logout() {
//    this.user.logOut();
//    this.router.navigate([`/login`], { relativeTo: this.route });
//  }
//  loadPilots() {
//    this.pilots = this.appConfig.user.facility.pilots;
//    const g3Pilot = this.pilots.filter(pilots => pilots.PilotName === 'EPMS Gate 3');
//    if (g3Pilot && g3Pilot.length > 0) {
//      this.inPilot = true;
//    } else {
//      this.inPilot = false;
//    }
//  }
//  updateMenu() {
//    this.items = [
//      {
//        label: 'Visit Prep',
//        styleClass: 'nav-link',
//        visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.VisitPrep),
//        items: [
//          // tslint:disable-next-line:max-line-length
//          { label: 'Appointment Confirmations', visible: this.inPilot && this.user.hasViewAccess(EpmsResourceAccess.apptconf_access_data), styleClass: 'nav-link', routerLink: ['/visit-prep/AppointmentConfirmation'], queryParams: { 'recent': 'true' } },
//          { label: 'Chart Audit',  visible: this.user.hasViewAccess(EpmsResourceAccess.chartaudit_access_data),
//           styleClass: 'nav-link', routerLink: ['/visit-prep/ChartAudit'], queryParams: { 'recent': 'true' } },
//          // tslint:disable-next-line:max-line-length
//          { label: 'Electronic Eligibility', visible: this.user.hasViewAccess(EpmsResourceAccess.eligibility_access_data),
//          styleClass: 'nav-link', routerLink: ['/visit-prep/Eligibility'], queryParams: { 'recent': 'true' } },

//        ]
//        //   , style: { 'color': '#337ab7' }
//      },

//      {
//        label: 'Administration',
//        styleClass: 'nav-link',  visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Administration),
//        items: [
//          {

//            label: 'Admin', styleClass: 'nav-link', visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Admin),
//            items: [
//              {
//                label: 'Job Code Management',
//                visible: this.user.hasViewAccess(EpmsResourceAccess.jcr_access_data),
//                 routerLink: ['/JobCodeManagement'], queryParams: { 'recent': 'true' }
//                , styleClass: 'nav-link',
//              },
//              {
//                label: 'Employee Override Management',
//                visible: this.user.hasViewAccess(EpmsResourceAccess.em_access_data),
//                routerLink: ['/EmployeeOverrideManagement'], queryParams: { 'recent': 'true' }
//                , styleClass: 'nav-link',
//              },
//              {
//                label: 'Secret Key', routerLink: ['/SecretKey'], queryParams: { 'recent': 'true' }
//                , styleClass: 'nav-link', visible: this.user.hasViewAccess(EpmsResourceAccess.sk_access_data),
//              },
//            ]


//          },
//          {
//            label: 'Events', styleClass: 'nav-link', visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.EventManagement),
//            items: [
//              {
//                label: 'Event Management', visible: this.user.hasViewAccess(EpmsResourceAccess.evm_access_data),
//                styleClass: 'nav-link', routerLink: ['/EventManagement'], queryParams: { 'recent': 'true' }

//              },
//              {
//                label: 'Event Settings', visible: this.user.hasViewAccess(EpmsResourceAccess.es_access_data),
//                styleClass: 'nav-link', routerLink: ['/EventSettings'], queryParams: { 'recent': 'true' }

//              }
//            ]
//          },
//          {
//            label: 'Schedule Management', styleClass: 'nav-link',
//            visible: this.inPilot && this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.ProviderScheduleManagement),
//            items: [
//              {
//                // tslint:disable-next-line:max-line-length
//                label: 'Modify/Copy a Schedule - Template', visible: this.user.hasViewAccess(EpmsResourceAccess.mp_mst_access_data),
//                styleClass: 'nav-link', routerLink: ['/ModifyScheduleTemplate'], queryParams: { 'recent': 'true' }

//              },
//              {
//                // tslint:disable-next-line:max-line-length
//                label: 'Modify a Schedule - Existing Week', visible: this.user.hasViewAccess(EpmsResourceAccess.mp_msw_access_data),
//                styleClass: 'nav-link', routerLink: ['/modifyaschedule'], queryParams: { 'recent': 'true' }

//              },
//              {
//                label: 'Schedule Block', styleClass: 'nav-link',
//                visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.ProviderScheduleManagement),

//                items: [
//                  {
//                    label: 'Chair', routerLink: ['/Chair'], visible: this.user.hasViewAccess(EpmsResourceAccess.mp_blsc_access_data),
//                    styleClass: 'nav-link', queryParams: { 'recent': 'true' }
//                  },
//                  {
//                    // tslint:disable-next-line:max-line-length
//                    label: 'Single Provider', visible: this.user.hasViewAccess(EpmsResourceAccess.mp_blss_access_data),
//                    styleClass: 'nav-link', routerLink: ['/Single Provider'], queryParams: { 'recent': 'true' }
//                  },
//                  {
//                    label: 'Office', visible: this.user.hasViewAccess(EpmsResourceAccess.mp_blso_access_data),
//                    styleClass: 'nav-link', routerLink: ['/Office'], queryParams: { 'recent': 'true' }
//                  }
//                ]


//              }
//            ]

//          },
//          {
//            label: 'Messages', styleClass: 'nav-link',
//            visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Messages),
//            items: [
//              {
//                // tslint:disable-next-line:max-line-length
//                label: 'Message Management', styleClass: 'nav-link', visible: this.user.hasViewAccess(EpmsResourceAccess.mm_access_data),
//                 routerLink: ['/MessageManagement'], queryParams: { 'recent': 'true' }

//              }
//            ]
//          },
//          {
//            label: 'Scheduling', styleClass: 'nav-link', visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Scheduling),
//            items: [
//              {
//                label: 'Reminders', styleClass: 'nav-link',
//                 routerLink: ['/Reminders'], queryParams: { 'recent': 'true' }

//              }
//            ]
//          },
//          {
//            label: 'Forms', styleClass: 'nav-link', visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Forms),
//            items: [
//              {
//                label: 'Message Management', styleClass: 'nav-link', visible: this.user.hasViewAccess(EpmsResourceAccess.cf_access_data),
//                 routerLink: ['/Consent Forms'], queryParams: { 'recent': 'true' }

//              }
//            ]
//          }, {
//            label: 'Document Management', styleClass: 'nav-link',
//            visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.DocumentManagement),
//            items: [
//              {
//                label: 'Clinical Notes', visible: this.user.hasViewAccess(EpmsResourceAccess.dmclf_access_data),
//                 styleClass: 'nav-link', routerLink: ['/framework/documentmapping/clinicalnote'], queryParams: { 'recent': 'true' }

//              },
//              {
//                label: 'Clinical Forms', visible: this.user.hasViewAccess(EpmsResourceAccess.dmclf_access_data),
//                 styleClass: 'nav-link', routerLink: ['/framework/documentmapping/clinicalforms'], queryParams: { 'recent': 'true' }

//              }
//            ]
//          }

//        ]
//      },
//      {
//        label: 'Visit Manager', visible: this.inPilot && this.user.hasViewAccess(EpmsResourceAccess.appt_book_access_data),
//        styleClass: 'nav-link', routerLink: ['/VisitManager'], queryParams: { 'recent': 'true' }
//      },
//      {
//        label: 'Clincal', visible: this.inPilot && this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Clinical),
//        styleClass: 'nav-link', routerLink: ['/clinical/seatpatient'], queryParams: { 'recent': 'true' }
//      },
//      {
//        label: 'Consult',
//        visible: this.inPilot && this.user.hasViewAccess(EpmsResourceAccess.consultq_access_data),
//        styleClass: 'nav-link', routerLink: ['/consult/consultq'], queryParams: { 'recent': 'true' }
//      },
//      {
//        label: 'Office Tools', styleClass: 'nav-link',
//        visible: this.inPilot && this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.OfficeTools),
//        items: [
//          // tslint:disable-next-line:max-line-length
//          { label: 'Tracker Board', styleClass: 'nav-link',
//           routerLink: ['/officetools/trackerboard'],
//            queryParams: { 'recent': 'true' } },
//          { label: 'End of Day', visible: this.user.hasViewAccess(EpmsResourceAccess.eod_access_data),
//          styleClass: 'nav-link', routerLink: ['/officetools/endofday'], queryParams: { 'recent': 'true' } },
//          { label: 'Reports', visible: this.user.hasViewAccess(EpmsResourceAccess.reports_access_data),
//           styleClass: 'nav-link', routerLink: ['/officetools/report'], queryParams: { 'recent': 'true' } },
//          {
//            label: 'OM Dashboard', visible: this.user.hasViewAccess(EpmsResourceAccess.omdashboard_access_data),
//            styleClass: 'nav-link', routerLink: ['/officetools/omdashboard'], queryParams: { 'recent': 'true' }
//          },
//          {
//            label: 'PSR Dashboard', visible: this.user.hasViewAccess(EpmsResourceAccess.psrdashboard_access_data),
//            styleClass: 'nav-link',
//            routerLink: ['/officetools/psrdashboard'], queryParams: { 'recent': 'true' }
//          },
//          {
//            label: 'Scheduling Notes',
//            styleClass: 'nav-link',
//            routerLink: ['/officetools/schedulenote'], queryParams: { 'recent': 'true' }
//          },
//          {
//            label: 'Operatory Names',
//            styleClass: 'nav-link',
//            routerLink: ['/officetools/operatorynames"'], queryParams: { 'recent': 'true' }
//          },
//        ]
//      },
//      { label: 'Scheduling Center', visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Scheduling),
//      styleClass: 'nav-link', routerLink: ['/Scheduling'], queryParams: { 'recent': 'true' } },
//      {
//        label: 'Patient Search', styleClass: 'nav-link', visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Patient),
//        items: [
//          { label: 'Search', styleClass: 'nav-link', visible: this.user.hasViewAccess(EpmsResourceAccess.search_access_data),
//           routerLink: ['/PatientSearch'], queryParams: { 'recent': 'true' } }
//        ]
//      }
//    ];
//  }
//  ngOnInit() {
//    this.menuObservableService.submenuObservableserver.subscribe(
//      menu => {
//        this.loadPilots();
//        this.updateMenu();
//      });
//    const idle = new Idle()
//      .whenNotInteractive()
//      .within(15)
//      .do(() => {
//        console.log('IDLE');
//        this.logout();
//        this.router.navigate([`/login`], { relativeTo: this.route });
//      })
//      .start();
//    this.loadPilots();
//    this.updateMenu();

//    this.menuObservableService.submenuPatientSearchObservableserver.subscribe(
//      patientSearch => {
//        this.items = [
//          {
//            label: 'Visit Prep',
//            styleClass: 'nav-link',
//            visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.VisitPrep),
//            items: [
//              // tslint:disable-next-line:max-line-length
//              { label: 'Appointment Confirmations', visible: this.inPilot && this.user.hasViewAccess(EpmsResourceAccess.apptconf_access_data), styleClass: 'nav-link', routerLink: ['/visit-prep/AppointmentConfirmation'], queryParams: { 'recent': 'true' } },
//              { label: 'Chart Audit',  visible: this.user.hasViewAccess(EpmsResourceAccess.chartaudit_access_data),
//               styleClass: 'nav-link', routerLink: ['/visit-prep/ChartAudit'], queryParams: { 'recent': 'true' } },
//              // tslint:disable-next-line:max-line-length
//              { label: 'Electronic Eligibility', visible: this.user.hasViewAccess(EpmsResourceAccess.eligibility_access_data),
//              styleClass: 'nav-link', routerLink: ['/visit-prep/Eligibility'], queryParams: { 'recent': 'true' } },

//            ]
//            //   , style: { 'color': '#337ab7' }
//          },

//          {
//            label: 'Administration',
//            styleClass: 'nav-link',  visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Administration),
//            items: [
//              {

//                label: 'Admin', styleClass: 'nav-link', visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Admin),
//                items: [
//                  {
//                    label: 'Job Code Management',
//                    visible: this.user.hasViewAccess(EpmsResourceAccess.jcr_access_data),
//                     routerLink: ['/JobCodeManagement'], queryParams: { 'recent': 'true' }
//                    , styleClass: 'nav-link',
//                  },
//                  {
//                    label: 'Employee Override Management',
//                    visible: this.user.hasViewAccess(EpmsResourceAccess.em_access_data),
//                    routerLink: ['/EmployeeOverrideManagement'], queryParams: { 'recent': 'true' }
//                    , styleClass: 'nav-link',
//                  },
//                  {
//                    label: 'Secret Key', routerLink: ['/SecretKey'], queryParams: { 'recent': 'true' }
//                    , styleClass: 'nav-link', visible: this.user.hasViewAccess(EpmsResourceAccess.sk_access_data),
//                  },
//                ]


//              },
//              {
//                label: 'Events', styleClass: 'nav-link', visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.EventManagement),
//                items: [
//                  {
//                    label: 'Event Management', visible: this.user.hasViewAccess(EpmsResourceAccess.evm_access_data),
//                    styleClass: 'nav-link', routerLink: ['/EventManagement'], queryParams: { 'recent': 'true' }

//                  },
//                  {
//                    label: 'Event Settings', visible: this.user.hasViewAccess(EpmsResourceAccess.es_access_data),
//                    styleClass: 'nav-link', routerLink: ['/EventSettings'], queryParams: { 'recent': 'true' }

//                  }
//                ]
//              },
//              {
//                label: 'Schedule Management', styleClass: 'nav-link',
//                visible: this.inPilot && this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.ProviderScheduleManagement),
//                items: [
//                  {
//                    // tslint:disable-next-line:max-line-length
//                    label: 'Modify/Copy a Schedule - Template', visible: this.user.hasViewAccess(EpmsResourceAccess.mp_mst_access_data),
//                    styleClass: 'nav-link', routerLink: ['/ModifyScheduleTemplate'], queryParams: { 'recent': 'true' }

//                  },
//                  {
//                    // tslint:disable-next-line:max-line-length
//                    label: 'Modify a Schedule - Existing Week', visible: this.user.hasViewAccess(EpmsResourceAccess.mp_msw_access_data),
//                    styleClass: 'nav-link', routerLink: ['/modifyaschedule'], queryParams: { 'recent': 'true' }

//                  },
//                  {
//                    label: 'Schedule Block', styleClass: 'nav-link',
//                    visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.ProviderScheduleManagement),

//                    items: [
//                      {
//                        label: 'Chair', routerLink: ['/Chair'], visible: this.user.hasViewAccess(EpmsResourceAccess.mp_blsc_access_data),
//                        styleClass: 'nav-link', queryParams: { 'recent': 'true' }
//                      },
//                      {
//                        // tslint:disable-next-line:max-line-length
//                        label: 'Single Provider', visible: this.user.hasViewAccess(EpmsResourceAccess.mp_blss_access_data),
//                        styleClass: 'nav-link', routerLink: ['/Single Provider'], queryParams: { 'recent': 'true' }
//                      },
//                      {
//                        label: 'Office', visible: this.user.hasViewAccess(EpmsResourceAccess.mp_blso_access_data),
//                        styleClass: 'nav-link', routerLink: ['/Office'], queryParams: { 'recent': 'true' }
//                      }
//                    ]


//                  }
//                ]

//              },
//              {
//                label: 'Messages', styleClass: 'nav-link',
//                visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Messages),
//                items: [
//                  {
//                    // tslint:disable-next-line:max-line-length
//                    label: 'Message Management', styleClass: 'nav-link', visible: this.user.hasViewAccess(EpmsResourceAccess.mm_access_data),
//                     routerLink: ['/MessageManagement'], queryParams: { 'recent': 'true' }
//                  }
//                ]
//              },
//              {
//                label: 'Scheduling', styleClass: 'nav-link', visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Scheduling),
//                items: [
//                  {
//                    label: 'Reminders', styleClass: 'nav-link',
//                     routerLink: ['/Reminders'], queryParams: { 'recent': 'true' }
//                  }
//                ]
//              },
//              {
//                label: 'Forms', styleClass: 'nav-link', visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Forms),
//                items: [
//                  {
//                    label: 'Message Management', styleClass: 'nav-link',
//                    visible: this.user.hasViewAccess(EpmsResourceAccess.cf_access_data),
//                     routerLink: ['/Consent Forms'], queryParams: { 'recent': 'true' }
//                  }
//                ]
//              }, {
//                label: 'Document Management', styleClass: 'nav-link',
//                visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.DocumentManagement),
//                items: [
//                  {
//                    label: 'Clinical Notes', visible: this.user.hasViewAccess(EpmsResourceAccess.dmclf_access_data),
//                     styleClass: 'nav-link', routerLink: ['/clinical_notes'], queryParams: { 'recent': 'true' }
//     },
//                  {
//                    label: 'Clinical Forms', visible: this.user.hasViewAccess(EpmsResourceAccess.dmclf_access_data),
//                     styleClass: 'nav-link', routerLink: ['/clinical_forms'], queryParams: { 'recent': 'true' }
//      }
//                ]
//              }]
//          },
//          {
//            label: 'Visit Manager', visible: this.inPilot && this.user.hasViewAccess(EpmsResourceAccess.appt_book_access_data),
//            styleClass: 'nav-link', routerLink: ['/VisitManager'], queryParams: { 'recent': 'true' }
//          },
//          {
//            label: 'Clincal', visible: this.inPilot && this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Clinical),
//            styleClass: 'nav-link', routerLink: ['/clinical/seatpatient'], queryParams: { 'recent': 'true' }
//          },
//          {
//            label: 'Consult',
//            visible: this.inPilot && this.user.hasViewAccess(EpmsResourceAccess.consultq_access_data),
//            styleClass: 'nav-link', routerLink: ['/consult/consultq'], queryParams: { 'recent': 'true' }
//          },
//          {
//            label: 'Office Tools', styleClass: 'nav-link',
//            visible: this.inPilot && this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.OfficeTools),
//            items: [
//              // tslint:disable-next-line:max-line-length
//              { label: 'Tracker Board', styleClass: 'nav-link',
//               routerLink: ['/officetools/trackerboard'],
//                queryParams: { 'recent': 'true' } },
//              { label: 'End of Day', visible: this.user.hasViewAccess(EpmsResourceAccess.eod_access_data),
//              styleClass: 'nav-link', routerLink: ['/officetools/endofday'], queryParams: { 'recent': 'true' } },
//              { label: 'Reports', visible: this.user.hasViewAccess(EpmsResourceAccess.reports_access_data),
//               styleClass: 'nav-link', routerLink: ['/officetools/report'], queryParams: { 'recent': 'true' } },
//              {
//                label: 'OM Dashboard', visible: this.user.hasViewAccess(EpmsResourceAccess.omdashboard_access_data),
//                styleClass: 'nav-link', routerLink: ['/officetools/omdashboard'], queryParams: { 'recent': 'true' }
//              },
//              {
//                label: 'PSR Dashboard', visible: this.user.hasViewAccess(EpmsResourceAccess.psrdashboard_access_data),
//                styleClass: 'nav-link',
//                routerLink: ['/officetools/psrdashboard'], queryParams: { 'recent': 'true' }
//              },
//              {
//                label: 'Scheduling Notes',
//                styleClass: 'nav-link',
//                routerLink: ['/officetools/schedulenote'], queryParams: { 'recent': 'true' }
//              },
//              {
//                label: 'Operatory Names',
//                styleClass: 'nav-link',
//                routerLink: ['/officetools/operatorynames"'], queryParams: { 'recent': 'true' }
//              },
//            ]
//          },
//          { label: 'Scheduling Center', visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Scheduling),
//          styleClass: 'nav-link', routerLink: ['/Scheduling'], queryParams: { 'recent': 'true' } },
//          {
//            label: 'Patient Search', styleClass: 'nav-link', visible: this.user.hasModuleAccess(EpmsResourceAccess.EpmsModules.Patient),
//           items: patientSearch
//          }
//        ];


//      });
//  }
// }

