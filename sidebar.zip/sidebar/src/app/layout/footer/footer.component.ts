import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html'
})
export class FooterComponent implements OnInit {
  currentYear = moment().year();
  currentEnvironment = environment.name;
  constructor() { }

  ngOnInit() {
  }

}
