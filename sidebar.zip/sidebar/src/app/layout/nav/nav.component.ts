import { Component, OnInit, HostListener, Output, EventEmitter } from '@angular/core';
import { SidemenuService } from 'src/app/shared/utils/sidemenu.service';
declare var $: any;

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  @Output() toggleDock = new EventEmitter();
  private sideMenuList: Array<any> = [];
  constructor(private sideMenus: SidemenuService) { }

  ngOnInit() {
     this.getSideMenuList();
  }
  private getSideMenuList(): void {
    this.sideMenuList = this.sideMenus.getSideMenus();
  }
  @HostListener('mousemove') expandSidebar() {
    this.toggleDock.emit();
  }
  private toggleExpand(menuList: string): void {
    for (const menu of this.sideMenuList) {
      if (menuList !== menu.id) {
        $('#' + menu.id).removeClass('show');
      }
    }
  }
}
