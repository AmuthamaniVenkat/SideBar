import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { SidemenuService } from 'src/app/shared/utils/sidemenu.service';
declare var $: any;

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class SidebarComponent implements OnInit {
  private _opened = true;
   sideMenuList: Array<any> = [];
  constructor(private sideMenus: SidemenuService) {
  }
  ngOnInit() {
    $('#faBar').css('background-color', '#2a6ebb');
    this.getSideMenuList();
  }
  public toggleOpenedForEmit(): void {
    if (!this._opened) {
    this._opened = !this._opened;
   setTimeout(() => {
    if ($('.main-sidebar').hasClass('ng-sidebar--opened')) {
      $('.sidebar-nav').removeClass('opened');
    }
    }, 100);
    } else {
      setTimeout(() => {
      if ($('.main-sidebar').hasClass('ng-sidebar--closed')) {
        this.removeClass();
      }
    }, 100);
    }
  }
  public openedChange(open: boolean): void {
    if (!this._opened) {
      this.removeClass();
    }
  }
  private getSideMenuList(): void {
    this.sideMenuList = this.sideMenus.getSideMenus();
  }
  private removeClass(): void {
    $('.sidebar-nav').addClass('opened');
    for (const menu of this.sideMenuList) {
        $('#' + menu.id).removeClass('show');
        console.log('#' + menu.id);
    }
  }
}
