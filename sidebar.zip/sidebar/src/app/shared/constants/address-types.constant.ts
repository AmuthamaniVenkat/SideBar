export enum addressTypesEnum {
    NotSpecified = 1,
    InsuranceAddress = 3,
    PersonalAddress = 4,
    Mailing = 5,
    Physical = 6,
    Business = 7
}
