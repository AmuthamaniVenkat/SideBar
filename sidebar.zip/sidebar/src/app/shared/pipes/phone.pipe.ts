import { Pipe, PipeTransform } from '@angular/core';

// tslint:disable-next-line:use-pipe-transform-interface
@Pipe({
    name: 'phone'
})
export class PhonePipe {
    transform(phone, args) {
        if (phone) {
            // Convert to a string
            let value = phone;

            // Remove non-numeric characters
          //  value = value.toString().replace(/\D/g, '');

            // If 11 digits long format like X (XXX) XXX-XXXX
            if (value.length === 14) {
                value = value.slice(0, 6) + '-' + value.slice(6);
                value = value.slice(0, 3) + ') ' + value.slice(3);
                value = '(' + value;
            }
            if (value.length === 11) {
                value = value.slice(0, 7) + '-' + value.slice(7);
                value = value.slice(0, 4) + ') ' + value.slice(4);
                value = value.slice(0, 1) + ' (' + value.slice(1);
            }

            // If 10 digits long format like (XXX) XXX-XXXX
            if (value.length === 10) {
                value = value.slice(0, 6) + '-' + value.slice(6);
                value = value.slice(0, 3) + ') ' + value.slice(3);
                value = '(' + value;
            }

            // If 7 digits long format like XXX-XXXX
            if (value.length === 7) {
                value = value.slice(0, 3) + '-' + value.slice(3);
            }
            return value;
        }
        return null;
    }
}
