import { Pipe, PipeTransform } from '@angular/core';

// tslint:disable-next-line:use-pipe-transform-interface
@Pipe({
    name: 'address'
})
export class AddressPipe {
    transform(address, args) {
        if (address) {
            let formatted = '';
            if (address) {
                if (address.Line1) {
                    formatted += address.Line1;
                }
                if (address.City) {
                    formatted += ' ' + address.City;
                }
                if (address.State) {
                    formatted += ', ' + address.State.Abbreviation;
                }
                if (address.ZipCode) {
                    formatted += ' ' + address.ZipCode;
                }
            }
            return formatted;

        }
        return null;
    }
}
