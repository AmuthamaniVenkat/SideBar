import { Pipe, PipeTransform } from '@angular/core';
import * as  moment from 'moment';
import * as _ from 'underscore';

@Pipe({
    name: 'datetimefilter'
})
export class DatetimePipe implements PipeTransform {
    transform(value: any, timeFormat): any {
        if (value != null) {
            //   'h:mm A ', 'M/D/YYYY h:mm:ss A'
            return moment.utc(value).local().format(timeFormat);
        }
    }
}
