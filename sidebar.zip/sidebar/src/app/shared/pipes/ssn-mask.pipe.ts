import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'ssnMask'
})
export class SsnMaskPipe implements PipeTransform {

  transform(value: number): string {
    if (value) {
    let newSSN = '';
    const tempSSN = value.toString().substring(5, 9);
    newSSN = '***-**-' + tempSSN;
    return newSSN;
  }
  return '';
  }

}
