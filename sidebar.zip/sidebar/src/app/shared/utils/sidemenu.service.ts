import { Injectable } from '@angular/core';
@Injectable()
export class SidemenuService {

  constructor() { }
  getSideMenus(): Array<any> {
    const sideMenus = [
                   {
                    label: 'demo',
                    id: 'demo',
                    visible: true,
                    level: 2,
                    icon: '',
                    routerLink: ['/demo'], children: [
                      {
                        label: 'demo 1',
                        id: 'demo1',
                        visible: true,
                        level: 2,
                        icon: '',
                        routerLink: ['/demo/demo1'], children: []
                       }
                    ]
                   },
                   {
                    label: 'Helps',
                    id: 'Helps',
                    visible: true,
                    level: 1,
                    icon: '',
                    routerLink: ['/helps'], children: []
                   },

    ];
    return sideMenus;
  }
}
