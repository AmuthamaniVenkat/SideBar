import { Injectable } from '@angular/core';

@Injectable()
export class BreadcrumbService {

  constructor() { }

  getBreadcrumb(): Array<any> {
    const Breadcrumb = [
      { name: 'Helps', path: './helps', children: [] },
      { name: 'Helps', path: './helps', children: [] },
      {
        name: 'clinical',
        path: './clinical',
        children: [
          {
            name: 'charting',
            path: './charting',
            children: [
              {
                name: 'THE FELLOWSHIP OF THE RING Details',
                path: './book1'
              },
              {
                name: 'THE RETURN OF THE KING',
                path: './book2'
              },
              {
                name: 'Harry Potter and the Philosopher\'s Stone',
                path: './book3'
              },
              {
                name: 'Harry Potter and the Chamber of Secrets',
                path: './book4'
              }
            ]
          }
        ]
      },
    ];

    return Breadcrumb;
  }

}
