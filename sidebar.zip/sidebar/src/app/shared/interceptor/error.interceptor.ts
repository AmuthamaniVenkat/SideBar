
import { tap } from 'rxjs/operators';
import { Injectable, ErrorHandler, Injector } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class UIErrorHandler extends ErrorHandler implements HttpInterceptor {
  constructor(private injector: Injector) {
    super();
  }
  handleError(error) {
    super.handleError(error);
    const date = new Date().toISOString();
    console.error(date, 'There was a error.', error.message);
  }
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // const messageService = this.injector.get(ToastrService);
    return next.handle(request).pipe(tap(event => { }, err => {
      // messageService.error('COMMUNICATION_ERROR');
      console.log(err + 'test');
    }));
  }
}
