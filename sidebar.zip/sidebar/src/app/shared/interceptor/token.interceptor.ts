
import { tap } from 'rxjs/operators';
import { Injectable, Inject } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable()
export class TokenInterceptor implements HttpInterceptor {
    constructor() {

    }
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        request = request.clone({
            setHeaders: {
                Authorization: `Bearer ${sessionStorage.getItem('authorizationData')}`,
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT',
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });
        //  return next.handle(request);
        return next.handle(request).pipe(tap(event => { }, err => {
            //  this.toastr.error('COMMUNICATION_ERROR');
            console.log(err);
            if (err instanceof HttpErrorResponse && err.status === 401) {
                // handle 401 errors
            }
            if (err instanceof HttpErrorResponse && err.status === 500) {
                // handle 500 errors
            }
        }));
    }
}
