export interface IfcSampleInterface {
    key: string;
    value: string;
 }
