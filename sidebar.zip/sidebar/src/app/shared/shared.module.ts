import { NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, Route, ExtraOptions, RouterModule, CanActivate, CanLoad } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CalendarModule } from 'primeng/calendar';
import { PanelModule, ButtonModule,  DataTableModule} from 'primeng/primeng';
import { CardComponent } from './components/card/card.component';
import { BreadcrumbService } from './utils/breadcrumb.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {TableModule} from 'primeng/table';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { SidemenuService } from './utils/sidemenu.service';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    // RouterModule.forChild(Routes),
    HttpClientModule,
    ReactiveFormsModule,
    CalendarModule,
    ScrollPanelModule,
    NgbModule
  ],
  declarations: [
    CardComponent
  ],
  exports: [
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    HttpClientModule,
    CalendarModule,
    PanelModule,
    ButtonModule,
    DataTableModule,
    CardComponent,
    NgbModule,
    TableModule,
    ScrollPanelModule
  ],
  schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA ],
  providers: [BreadcrumbService, SidemenuService
  ]
})
export class SharedModule { }
