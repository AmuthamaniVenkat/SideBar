import { Injectable } from '@angular/core';
import { CanActivate, CanDeactivate, CanActivateChild, Router, ActivatedRoute, NavigationEnd, RouterStateSnapshot, ActivatedRouteSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ReloadRouteGuard implements CanActivate, CanDeactivate<CanComponentDeactivate> {
  constructor(private router: Router, private route: ActivatedRoute) { }
  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    this.router.onSameUrlNavigation = 'reload';
    return true;
  }
  canDeactivate(component: CanComponentDeactivate, currentRoute: ActivatedRouteSnapshot, currentState: RouterStateSnapshot, nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    this.router.onSameUrlNavigation = 'ignore';
    return true;
  }
}
export interface CanComponentDeactivate {
  canDeactivate: () => Observable<boolean> | Promise<boolean> | boolean;
}
