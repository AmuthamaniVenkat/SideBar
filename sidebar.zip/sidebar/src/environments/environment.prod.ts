export const environment = {
  production: true,
  name: '',
  api: { // API Endpoints
    epmsApi: 'http://localhost:42932/'
  },
  links: { // external links based on env
    educationLink: 'http://uat-idct/#/login?office={0}&amp;accountNumber={1}&amp;name={2}'
  },
  paths: {
    uploadPath: '',
  }
};
